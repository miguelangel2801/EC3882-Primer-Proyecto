/* ###################################################################
**     Filename    : main.c
**     Project     : Prueba-03
**     Processor   : MC9S08QE128CLK
**     Version     : Driver 01.12
**     Compiler    : CodeWarrior HCS08 C Compiler
**     Date/Time   : 2019-03-06, 15:40, # CodeGen: 0
**     Abstract    :
**         Main module.
**         This module contains user's application code.
**     Settings    :
**     Contents    :
**         No public methods
**
** ###################################################################*/
/*!
** @file main.c
** @version 01.12
** @brief
**         Main module.
**         This module contains user's application code.
*/         
/*!
**  @addtogroup main_module main module documentation
**  @{
*/         
/* MODULE main */


/* Including needed modules to compile this module/procedure */
#include "Cpu.h"
#include "Events.h"
#include "AD1.h"
#include "Bit1.h"
#include "AS1.h"
#include "TI1.h"
#include "Bit2.h"
#include "Bit3.h"
#include "Bit4.h"
/* Include shared modules, which are used for whole project */
#include "PE_Types.h"
#include "PE_Error.h"
#include "PE_Const.h"
#include "IO_Map.h"

/* User includes (#include below this line is not maintained by Processor Expert) */
int lectura0;
int lectura1;
char array[4];
char flag;
int *puntblock;
char ensayo[20][4];
int n1=0;
int n2=0;
bool dig;
int leerADC12_00(int var){//Leo el ADC y lo mando a una variable de 12bits
	char error;
	if(AD1_MeasureChan(TRUE,0)==ERR_OK){
	do{
	error=AD1_GetChanValue(0,&var);
	}while(error!=ERR_OK);
	
	return var;}
}
int leerADC12_01(int var){//Leo el ADC y lo mando a una variable de 12bits
	char error;
	if(AD1_MeasureChan(TRUE,0)==ERR_OK){
	do{
	error=AD1_GetChanValue(1,&var);
	}while(error!=ERR_OK);
	return var;}
}
int leerADC12_02(int var){//Leo el ADC y lo mando a una variable de 12bits
	char error;
	AD1_Measure(TRUE);
	do{
	error=AD1_GetChanValue(2,&var);
	}while(error!=ERR_OK);
	return var;
}
int leerADC12_03(int var){//Leo el ADC y lo mando a una variable de 12bits
	char error;
	AD1_Measure(TRUE);
	do{
	error=AD1_GetChanValue(3,&var);
	}while(error!=ERR_OK);
	return var;
}
char mitadSUP(int entrada){ //Pico el int donde est� almacenado la lectura del ADC y me quedo
							//S�lo con la mitad superior (6bits m�s significativos)
	int aux;
	aux=entrada;
	aux=aux>>6;
	aux=aux & 0b00111111;
	return aux;
	}
char mitadINF(int entrada){ //Pico el int donde est� almacenado la lectura del ADC y me quedo
							//S�lo con la mitad inferior (6bits menos significativos)
	int aux;
	aux=entrada;
	//aux=aux>>4;		
	aux=aux & 0b00111111;
	return aux;
	}
void enviarmensaje(char msj){ //PRIMERA PRUEBA PARA ENVIAR DE 1 EN 1 BYTE
	int error;
	do{
		error=AS1_SendChar(msj);
	}while(error!=ERR_OK);
}
void llenararreglo(int var){ //Solo llena parte anal�gica.
	var=leerADC12_00(var);
	array[0]=mitadSUP(var);       //Inicio de mensaje tipo 00111111 PRIMER BYTE
	array[1]=mitadINF(var);	      //Inicio de SEGUNDO BYTE tipo 10111111
	//var=leerADC12_01(var);        
	array[2]=mitadSUP(var);       //Inicio de TERCER BYTE tipo 10111111
	array[3]=mitadINF(var);	      //Inicio de CUARTO BYTE tipo 10111111
	
}

void acondicionartrama(char array[]){	//Prepara el arreglo para ser enviado cumpliendo el protocolo
										//FUNCIONA FALTA AGREGAR DIGITAL.
	
	array[1]=array[1]+0b10000000;
	lectura0=leerADC12_02(lectura0);
		if(lectura0>=2048){
			lectura0=0b01000000;
		}else lectura0=0;
	array[1]=array[1]+lectura0;
	array[2]=array[2]+0b10000000;
	lectura0=leerADC12_03(lectura0);
		if(lectura0>=2048){
			lectura0=0b01000000;
		}else lectura0=0;
	array[2]=array[2]+lectura0;
	array[3]=array[3]+0b10000000;
}
void acondicionartrama1(char array[]){	//Prepara el arreglo para ser enviado cumpliendo el protocolo
										//FUNCIONA FALTA AGREGAR DIGITAL.
	
	array[1]=array[1]+0b10000000;
	dig=Bit2_GetVal();
		if(dig!=1){
			lectura0=0;
		}else lectura0=0b01000000;
	array[1]=array[1]+lectura0;
	array[2]=array[2]+0b10000000;
	dig=Bit3_GetVal();
		if(dig!=1){
			lectura0=0;
		}else lectura0=0b01000000;
	array[2]=array[2]+lectura0;
	array[3]=array[3]+0b10000000;
}
void main(void)
{
  /* Write your local variable definition here */

  /*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/
  PE_low_level_init();
  /*** End of Processor Expert internal initialization.                    ***/

  /* Write your code here */
  /* For example: for(;;) { } */
while(1){
	/*if(flag==1) {	
			flag=0;
			Bit1_NegVal();
			llenararreglo(lectura0);
			acondicionartrama1(array);

			ensayo[n1][0]=array[0];
			ensayo[n1][1]=array[1];
			ensayo[n1][2]=array[2];
			ensayo[n1][3]=array[3];
			Bit1_NegVal();
			n1++;
	}
	if(n1>=20){
	for(n2=0;n2<20;n2++){
		array[0]=ensayo[n2][0];
		array[1]=ensayo[n2][1];
		array[2]=ensayo[n2][2];
		array[3]=ensayo[n2][3];
		AS1_SendBlock(array,4,puntblock);
	}n1=0;}*/
	if(flag==1){	
			flag=0;
			Bit1_NegVal();
			llenararreglo(lectura0);
			acondicionartrama1(array);
			AS1_SendBlock(array,4,puntblock);
			Bit1_NegVal();
		
				
	}
}    
  /*** Don't write any code pass this line, or it will be deleted during code generation. ***/
  /*** RTOS startup code. Macro PEX_RTOS_START is defined by the RTOS component. DON'T MODIFY THIS CODE!!! ***/
  #ifdef PEX_RTOS_START
    PEX_RTOS_START();                  /* Startup of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of RTOS startup code.  ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;){}
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/

/* END main */
/*!
** @}
*/
/*
** ###################################################################
**
**     This file was created by Processor Expert 10.3 [05.09]
**     for the Freescale HCS08 series of microcontrollers.
**
** ###################################################################
*/
